declare const Button: () => import("react/jsx-runtime").JSX.Element;
export default Button;
